#!/bin/sh

rm amiyabot-arknights-hsyhhssyy-furniture-1.0.zip
zip -q -r amiyabot-arknights-hsyhhssyy-furniture-1.0.zip *