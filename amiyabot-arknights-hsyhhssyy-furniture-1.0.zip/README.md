> 兔兔查询家具
    - 发送 `兔兔查询家具套装[家具套装名字]` 可以查询该套装下拥有的家具
    - 发送 `兔兔查询家具套装` 可以列出所有家具套装，然后回复数字可以查询该套装下的家具
    - 效果如如下图所示

![兔兔选助理例子](https://raw.githubusercontent.com/hsyhhssyy/amiyabot-arknights-hsyhhssyy-furniture/master/example.jpg)

> [项目地址:Github](https://github.com/hsyhhssyy/amiyabot-arknights-hsyhhssyy-furniture/)